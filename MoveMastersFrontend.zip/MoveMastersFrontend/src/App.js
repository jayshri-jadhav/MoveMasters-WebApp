import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import NavigationBar from './Components/NavigationBar';
import ServicesLayout from './Components/ServiceLayout';
import Register from './Components/Register';
import CustomerPage from './Components/CustomerPage';
import Orders from './Components/Orders';
import NewOrder from './Components/NewOrder';
import Profile from './Components/Profile';
import PaymentList from './Components/PaymentList';
import PaymentOptions from './PaymenOptions/PaymentOptions';
import CreditCardPayment from './PaymenOptions/CreditCardPayment';
import UPI from './PaymenOptions/UPI';
import './CSS/CreditCard.css';
import PaymentSuccess from './PaymenOptions/PaymentSuccess';
import AdminPage from './Components/AdminPage';

function App() {
  return (
    <Router>
      <>
      <NavigationBar />
      {/* <AdminPage/> */}
        <Switch>
        <Route exact path='/' component={ServicesLayout}/>
          <Route path='/login' component={Register} />
          <Route path='/customerpage' component={CustomerPage} />
          <Route path='/order' component={Orders} />
          <Route path='/neworder' component={NewOrder} />
          <Route path="/profile" component={Profile} />
          <Route path="/paymentlist" component={PaymentList} />
          <Route path="/payment" component={PaymentOptions}/>
          <Route path="/creditcard" component={CreditCardPayment}/>
          <Route path="/upi" component={UPI}/>
          <Route path="/success" component={PaymentSuccess}/>
          <Route path="/adminpage" component={AdminPage}/>
        </Switch>
      </>
    </Router>
  );
}

export default App;
