import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import QRCode from 'qrcode.react';

const UpiPayment = ({ amount }) => {
    const [upiId, setUpiId] = useState('');
    const [upiIdError, setUpiIdError] = useState(false);
    const history = useHistory();

    const handlePayment = () => {
        if (!upiId) {
            setUpiIdError(true);
            return;
        }

        console.log('UPI Payment submitted:', { upiId, amount });

        history.push('/success');

        setUpiId('');
        setUpiIdError(false);
    };

    return (
        <div className="container">
            <div className="row">
                <div className="col-lg-8">
                    <h2 style={{ color: 'blue' }}>UPI Payment</h2>
                    <form>
                        <div className={'form-group ' + (upiIdError ? 'error' : '')}>
                            <label>UPI ID</label>
                            <input
                                type="text"
                                className={'form-control ' + (upiIdError ? 'error-input' : '')}
                                value={upiId}
                                onChange={(e) => setUpiId(e.target.value)}
                                placeholder="Enter UPI ID"
                            />
                        </div>
                        <div className="form-group">
                            <label>Amount</label>
                            <input
                                type="text"
                                className="form-control"
                                value={amount}
                                readOnly 
                            />
                        </div>
                        <br />
                        <button type="button" className="btn btn-primary" onClick={handlePayment}>
                            Pay Now
                        </button>
                    </form>
                </div>
                <div className="col-lg-4">
                    {upiId && (
                        <div>
                            <h3>Scan QR Code to Pay</h3>
                            <QRCode value={'upi://' + upiId + '?amount=' + amount} />
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
}

export default UpiPayment;
