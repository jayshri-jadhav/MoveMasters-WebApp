import React from 'react';
import Card from 'react-bootstrap/Card';
import Button from 'react-bootstrap/Button';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMobile } from '@fortawesome/free-solid-svg-icons'; // Import the icon you need
import { useHistory } from 'react-router-dom';

const PaymentOptions = ({ location }) => {
    const totalPrice = new URLSearchParams(location.search).get('totalPrice') || 0;
    const history = useHistory();

    const handleUpiPayment = () => {
        history.push({
            pathname: '/success',
            state: { amount: totalPrice }
        });
    };

    return (
        <div className="container">
            <div className="row justify-content-center">
                <div className="col-lg-6">
                    <Card className="shadow-sm">
                        <Card.Body>
                            <Card.Title className="text-center mb-4">Select Payment Option</Card.Title>
                            <div className="text-center mb-4">
                                <p className="lead">Total Amount: <span className="text-primary">{totalPrice} ₹</span></p>
                            </div>
                            <div className="d-flex justify-content-center">
                                <Button onClick={handleUpiPayment} className="btn btn-success mr-2">
                                    <FontAwesomeIcon icon={faMobile} className="mr-2" /> Pay with UPI
                                </Button>
                            </div>
                        </Card.Body>
                    </Card>
                </div>
            </div>
        </div>
    );
}

export default PaymentOptions;
