import React, { useEffect } from 'react';
import '../CSS/PaymentSuccessStyle.css';
import httpClient from '../http-common';

const PaymentSuccess = () => {
    // Retrieve customer and order info from local storage
    var customer = JSON.parse(localStorage.getItem('customer'));
    var orderInfo = JSON.parse(localStorage.getItem('orderInfo'));
    console.log(orderInfo.weight);
    // Generate random transaction ID (16 digits)
    const generateRandomId = (length) => {
        const characters = '0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * characters.length));
        }
        return result;
    };
    const transactionId = generateRandomId(16);

    // Construct request object
    const request = {
        weight: parseInt(orderInfo.weight),
        cost: parseInt(orderInfo.cost),
        customerId: parseInt(customer.id),
        pickupAddress: orderInfo.pickupAddress,
        deliveryAddress: orderInfo.deliveryAddress,
        orderId:orderInfo.id
    };
    const orderId = orderInfo.orderId;
    console.log(request.pickupAddress);
    console.log(request.deliveryAddress);

    // Send request to server
    httpClient.post("/requests", {
        "customerId": customer.id, // Using customer ID
        "weight": parseInt(orderInfo.weight),
        "cost": parseInt(orderInfo.cost),
        "pickupAddress": orderInfo.pickupAddress,
        "deliveryAddress": orderInfo.deliveryAddress,
        "orderId":orderInfo.id
    })
    .then((response) => {
        console.log('Request sent successfully:', response.data);
    })
    .catch((error) => {
        console.error('Error sending request:', error);
    });

    return (
        <div className="container">
            <div className="payment-success">
                <h2>Payment Successful!</h2>
                <div className="transaction-info">
                    <p>Transaction ID: {transactionId}</p>
                    <p>Booking ID: {orderId}</p>
                </div>
            </div>
        </div>
    );
};

export default PaymentSuccess;
