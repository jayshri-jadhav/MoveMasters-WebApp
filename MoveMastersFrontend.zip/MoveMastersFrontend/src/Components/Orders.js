import React, { useState, useEffect } from 'react';
import Table from 'react-bootstrap/Table';
import {getOrder} from '../Services/OrderService';

export default function Orders() {
    const [orderData, setOrderData] = useState([]);

    useEffect(() => {
        const customerInfo = localStorage.getItem('customer');
        const customerInfoData=JSON.parse(customerInfo);
        console.log(parseInt(customerInfoData.id))
        getOrder(parseInt(customerInfoData.id))
            .then((response) => {
                setOrderData(response.data);
                console.log(response.data);
            })
            .catch((error) => {
                console.log(error);
            });
    }, []); 

    return (
        <div style={{ display: 'flex', justifyContent: 'center', padding: '0 20px' }}>
            <div>
            
                {orderData.length > 0 && (
                    <Table responsive bordered style={{ backgroundColor: '#f0f0f0', border: '1px solid #ccc', borderRadius: '8px' }}>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Cost</th>
                                <th>Delivery Date Time</th>
                                <th>Order Status</th>
                                <th>Shipping Date Time</th>
                                <th>Weight</th>
                            </tr>
                        </thead>
                        <tbody>
                            {orderData.map((order, index) => (
                                <tr key={index}>
                                    <td>{order[0]}</td>
                                    <td>Rs.{order[1]} </td>
                                    <td>{order[2]}</td>
                                    <td>{order[3]}</td>
                                    <td>{order[4]}</td>
                                    <td>{order[5]} Kg</td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                )}
            </div>
        </div>
    );
}
