import React, { useState } from 'react';

export const DeliveryAddressForm = ({ formData, handleInputChange, handleStateChange, majorCitiesByState, indianStates }) => {
    
    const [weight, setWeight] = useState('');
  const [vehicleType, setVehicleType] = useState('Car');
  const [pickupFormData, setPickupFormData] = useState({
    pickupPincode: '',
    pickupAddress: '',
    pickupCity: '',
    pickupState: '',
  });
  const [deliveryFormData, setDeliveryFormData] = useState({
    deliveryPincode: '',
    deliveryAddress: '',
    deliveryCity: '',
    deliveryState: '',
  });

  const handleInputChange = (e, formDataSetter) => {
    const { name, value } = e.target;
    // Validation rules
    let newValue = value;
    if (name === 'weight') {
      // Allow only positive numbers
      newValue = value.replace(/[^0-9]/g, '');
    } else {
      // Allow alphabets, space, and '-'
      newValue = value.replace(/[^a-zA-Z\s-]/g, '');
    }
    formDataSetter((prevData) => ({ ...prevData, [name]: newValue }));
  };

  const handleStateChange = (e, formDataSetter) => {
    const { value } = e.target;
    formDataSetter((prevData) => ({ ...prevData, registerState: value, registerCity: '' }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Order submitted:', {
      weight,
      vehicleType,
      pickupFormData,
      deliveryFormData,
    });
    setWeight('');
    setVehicleType('Car');
    setPickupFormData({ pickupPincode: '', pickupAddress: '', pickupCity: '', pickupState: '' });
    setDeliveryFormData({ deliveryPincode: '', deliveryAddress: '', deliveryCity: '', deliveryState: '' });
  };


    return (
      <div>
        <h2>Delivery Address</h2>
        <div className="mb-3">
          <label htmlFor="deliveryState" className="form-label">State</label>
          <select
            className="form-select"
            id="deliveryState"
            name="deliveryState"
            value={formData.deliveryState}
            onChange={handleStateChange}
            required
          >
            <option value="">Select State</option>
            {indianStates.map((state, index) => (
              <option key={index} value={state}>{state}</option>
            ))}
          </select>
        </div>
        <div className="mb-3">
          <label htmlFor="deliveryFlat" className="form-label">Flat No</label>
          <input
            type="text"
            className="form-control"
            id="deliveryFlat"
            name="deliveryFlat"
            value={formData.deliveryFlat}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="deliveryAddress" className="form-label">Building name</label>
          <input
            type="text"
            className="form-control"
            id="deliveryAddress"
            name="deliveryAddress"
            value={formData.deliveryAddress}
            onChange={handleInputChange}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="deliveryCity" className="form-label">City</label>
          <select
            className="form-select"
            id="deliveryCity"
            name="deliveryCity"
            value={formData.deliveryCity}
            onChange={handleInputChange}
            required
          >
            <option value="">Select City</option>
            {majorCitiesByState[formData.deliveryState]?.map((city, index) => (
              <option key={index} value={city}>{city}</option>
            ))}
          </select>
        </div>
        <div className="mb-3">
          <label htmlFor="deliveryPincode" className="form-label">Pincode</label>
          <input
            type="text"
            className="form-control"
            id="deliveryPincode"
            name="deliveryPincode"
            value={formData.deliveryPincode}
            onChange={handleInputChange}
            required
          />
        </div>
      </div>
    );
  };
