import React, { useState } from 'react';
import CustomerService from '../Services/CustomerService';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FaEdit, FaSave } from 'react-icons/fa';
import httpClient from '../http-common';

const Profile = () => {
  const initialCustomerData = JSON.parse(localStorage.getItem('customer'));
  const [customer, setCustomer] = useState(initialCustomerData);
  const [isEditing, setIsEditing] = useState(false);
  const [editedCustomer, setEditedCustomer] = useState(initialCustomerData); // Initialize with initial data
  const [isProfileVisible, setIsProfileVisible] = useState(true);

  // Function to handle edit click
  const handleEditClick = () => {
    setIsEditing(true);
    setIsProfileVisible(false);
  };

  // Function to handle save click
  const handleSaveClick = () => {
    console.log(editedCustomer);
    httpClient
      .put(`/customer/${customer.id}`, editedCustomer)
      .then((response) => {
        console.log(response);
        localStorage.setItem('customer', JSON.stringify(response.data));
        setCustomer(response.data);
        setIsEditing(false);
        setIsProfileVisible(true);
      })
      .catch((error) => {
        console.error(error);
      });
  };

  // Function to handle input change for first name and last name
  const handleNameChange = (e) => {
    const { name, value } = e.target;
    setEditedCustomer({ ...editedCustomer, [name]: value }); // Update editedCustomer state
  };

  // Function to handle input change for email and phone number
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditedCustomer({ ...editedCustomer, [name]: value }); // Update editedCustomer state
  };

  // Function to handle update button click
  const handleUpdateClick = () => {
    setIsEditing(false);
    setIsProfileVisible(true);
  };

  return (
    <div className="container mt-5">
      <h2>
        Customer Details{' '}
        {isEditing ? (
          <button className="btn btn-link" onClick={handleSaveClick}>
            <FaSave />
          </button>
        ) : (
          <button className="btn btn-link" onClick={handleEditClick}>
            <FaEdit />
          </button>
        )}
      </h2>
      {isProfileVisible && (
        <div className="card">
          <div className="card-body">
            <h5 className="card-title">First Name: {customer.firstName}</h5>
            <h5 className="card-title">Last Name: {customer.lastName}</h5>
            <p className="card-text">Email: {customer.email}</p>
            <p className="card-text">Phone Number: {customer.phoneNumber}</p>
            {isEditing && (
              <button className="btn btn-primary" onClick={handleUpdateClick}>
                Update
              </button>
            )}
          </div>
        </div>
      )}
      {isEditing && (
        <div className="card mt-3">
          <div className="card-body">
            <input
              type="text"
              className="form-control mb-2"
              name="firstName"
              value={editedCustomer.firstName}
              onChange={handleNameChange}
            />
            <input
              type="text"
              className="form-control mb-2"
              name="lastName"
              value={editedCustomer.lastName}
              onChange={handleInputChange}
            />
            <input
              type="email"
              className="form-control mb-2"
              name="email"
              value={editedCustomer.email} 
              onChange={handleInputChange}
            />
            <input
              type="text"
              className="form-control mb-2"
              name="phoneNumber"
              value={editedCustomer.phoneNumber} 
              onChange={handleInputChange}
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default Profile;
