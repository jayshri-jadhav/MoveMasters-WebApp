export class Order{
    constructor(id,weight,cost,orderStatus,shippingDateTime,deliveryDateTime,pickup_address,drop_address)
    {
        this.id = id;
        this.OrderStatus = orderStatus;
        this.OrderDateTime = deliveryDateTime;
        this.orderStatus = orderStatus;
        this.shippingDateTime = pickup_address;
        this.deliveryDateTime= deliveryDateTime;
        this.orderStatus = orderStatus;
        this.shippingDateTime=shippingDateTime;
    }
}

