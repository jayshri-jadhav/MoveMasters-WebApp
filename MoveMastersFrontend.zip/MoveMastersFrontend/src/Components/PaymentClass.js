
class Payment {
    constructor(id, transactionId, amount, paymentType) {
      this.id = id;
      this.transactionId = transactionId;
      this.amount = amount;
      this.paymentType = paymentType;
    }
  }
  
  export default Payment;
  