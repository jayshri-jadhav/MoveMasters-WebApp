
class Customer {
    constructor(id, firstname, lastname, email, password, phoneno) {
      this.id = id;
      this.firstname = firstname;
      this.lastname = lastname;
      this.email = email;
      this.password = password;
      this.phoneno = phoneno;
    }
  }
  
  export default Customer;
  