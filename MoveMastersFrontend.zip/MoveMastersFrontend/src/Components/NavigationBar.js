import React from 'react';
import { Container, Nav, Navbar, Button } from 'react-bootstrap'; 
import { useHistory } from 'react-router-dom'; 

function NavigationBar() {
  const isLoggedIn = localStorage.getItem('customer');
  const history = useHistory(); 

  const handleLogout = () => {
    // Handle logout by removing customer data from localStorage
    localStorage.removeItem('customer');
    // Redirect to home page after logout
    history.push('/');
  };

  return (
    <>
      <Navbar collapseOnSelect expand="md" bg="light" variant="light">
        <Container fluid>
          <Navbar.Brand href="/">
            <img
              src="logo.jpg"
              alt="MoveMasters Logo"
              style={{
                maxWidth: '150px',
                marginRight: 'auto',
              }}
            />
          </Navbar.Brand>

          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse id="responsive-navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link href="/customerpage" style={{ color: 'black', fontSize: '18px' }}>
                <b>Commercial</b>
              </Nav.Link>
              <Nav.Link href="/delivery_partner" style={{ color: 'black', fontSize: '18px' }}>
                <b>Delivery Partner</b>
              </Nav.Link>
            </Nav>
          </Navbar.Collapse>

          {/*  login/logout button based on user login status */}
          <Navbar.Collapse className="justify-content-end">
            <Nav>
              {isLoggedIn ? (
                <Button variant="outline-dark" onClick={handleLogout}>
                  <b>Logout</b>
                </Button>
              ) : (
                <a href="/login" className="btn btn-outline-dark">
                  <b>Login</b>
                </a>
              )}
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    </>
  );
}

export default NavigationBar;

