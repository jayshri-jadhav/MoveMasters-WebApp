import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import httpClient from '../http-common';


const OrderForm = () => {
  const [weight, setWeight] = useState('');
  const [vehicleType, setVehicleType] = useState('Car');
  const [orderId, setOrderId] = useState(null); // Define orderId state variable

  const [pickupFormData, setPickupFormData] = useState({
    pickupFlat: '',
    pickupAddress: '',
    pickupCity: '',
    pickupState: '',
    pickupPincode: '',
    pickupStreet: ''
  });

  const [deliveryFormData, setDeliveryFormData] = useState({
    deliveryFlat: '',
    deliveryAddress: '',
    deliveryCity: '',
    deliveryState: '',
    deliveryPincode: '',
    deliveryStreet: ''
  });

  const history = useHistory();

  const handlePickupInputChange = (e) => {
    const { name, value } = e.target;
    let newValue = value;

    if (name === 'pickupPincode') {
      newValue = value.replace(/[^0-9-]/g, '').substring(0, 6);
    } else if (name === 'pickupAddress' || name === 'pickupCity' || name === 'pickupStreet') {
      newValue = value.replace(/[^a-zA-Z\s-]/g, '');
    } else if (name === 'pickupFlat') {
      newValue = value.replace(/[^0-9-]/g, '');
    }

    setPickupFormData({ ...pickupFormData, [name]: newValue });
  };

  const handleDeliveryInputChange = (e) => {
    const { name, value } = e.target;
    let newValue = value;

    if (name === 'deliveryPincode') {
      newValue = value.replace(/[^0-9-]/g, '').substring(0, 6);
    } else if (name === 'deliveryAddress' || name === 'deliveryCity' || name === 'deliveryStreet') {
      newValue = value.replace(/[^a-zA-Z\s-]/g, '');
    } else if (name === 'deliveryFlat') {
      newValue = value.replace(/[^0-9-]/g, '');
    }

    setDeliveryFormData({ ...deliveryFormData, [name]: newValue });
  };

  const handlePickupStateChange = (e) => {
    const { value } = e.target;
    setPickupFormData({ ...pickupFormData, pickupState: value, pickupCity: '' });
  };

  const handleDeliveryStateChange = (e) => {
    const { value } = e.target;
    setDeliveryFormData({ ...deliveryFormData, deliveryState: value, deliveryCity: '' });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Order submitted:', { weight, vehicleType, pickupFormData, deliveryFormData });
    setWeight('');
    setVehicleType('Car');
    setPickupFormData({
      pickupFlat: '',
      pickupAddress: '',
      pickupCity: '',
      pickupState: '',
      pickupPincode: '',
      pickupStreet: '',
    });
    setDeliveryFormData({
      deliveryFlat: '',
      deliveryAddress: '',
      deliveryCity: '',
      deliveryState: '',
      deliveryPincode: '',
      deliveryStreet: '',
    });
  };

  const majorCitiesByState = {
    'Maharashtra': ['Mumbai', 'Pune', 'Nagpur', 'Thane', 'Nashik', 'Ahilyadevi Nagar'],
  };
  const indianStates = Object.keys(majorCitiesByState);

  const updateVehicleType = (newWeight) => {
    if (newWeight < 50) {
      setVehicleType('Bike');
    } else if (newWeight >= 50 && newWeight <= 200) {
      setVehicleType('Tempo');
    } else {
      setVehicleType('Truck');
    }

  };

  const handleWeightChange = (e) => {
    const { value } = e.target;
    const newWeight = value.replace(/[^0-9]/g, '');
    setWeight(newWeight);
    updateVehicleType(newWeight);
  };

  let cost = 0;
  if (vehicleType === 'Bike') 
  {
    if (pickupFormData.pickupCity === deliveryFormData.deliveryCity) 
    {
      cost = 9 * weight;
    } 
    else 
    {
      cost = 3 * (9 * weight);
    }
  }
  else if (vehicleType === 'Tempo')
  {
    if (pickupFormData.pickupCity === deliveryFormData.deliveryCity) 
    {
      cost = 79 * weight;
    }
    else 
    {
      cost = 3*(79 * weight);
    }
  }
  else if (vehicleType === 'Truck') 
  {
    if (pickupFormData.pickupCity === deliveryFormData.deliveryCity) 
    {
      cost = 159 * weight;
    }
    else 
    {
      cost = 3(159 * weight);
    }
  }

  const pickupAddress = `${pickupFormData.pickupFlat}, ${pickupFormData.pickupAddress}, ${pickupFormData.pickupStreet}, ${pickupFormData.pickupCity}, ${pickupFormData.pickupState}, ${pickupFormData.pickupPincode}`.toString();
  console.log(pickupAddress)

  // Construct delivery address string
  const deliveryAddress = `${deliveryFormData.deliveryFlat}, ${deliveryFormData.deliveryAddress}, ${deliveryFormData.deliveryStreet}, ${deliveryFormData.deliveryCity}, ${deliveryFormData.deliveryState}, ${deliveryFormData.deliveryPincode}`.toString();



    const handleSubmitOrder = (e) => {
      e.preventDefault();
      console.log('Order submitted:', { weight, vehicleType, pickupFormData, deliveryFormData });
      localStorage.setItem('orderInfo', JSON.stringify({ weight, vehicleType, pickupAddress, deliveryAddress }));
      setWeight('');
      setVehicleType('Car');
      // setPickupFormData({
      //   pickupFlat: '',
      //   pickupAddress: '',
      //   pickupCity: '',
      //   pickupState: '',
      //   pickupPincode: '',
      //   pickupStreet: '',
      // });
      // setDeliveryFormData({
      //   deliveryFlat: '',
      //   deliveryAddress: '',
      //   deliveryCity: '',
      //   deliveryState: '',
      //   deliveryPincode: '',
      //   deliveryStreet: '',
      // });

      const customerData = JSON.parse(localStorage.getItem('customer'));
      const customerId = customerData.id ;

      httpClient.post(`/order/addOrder/${customerId}`, {
        "weight": weight,
        "cost": cost, 
        "pickupAddress": {
          "city": pickupFormData.pickupCity,
          "pinCode": pickupFormData.pickupPincode,
          "flatNo": pickupFormData.pickupFlat,
          "buildingName": pickupFormData.pickupAddress,
          "streetName": pickupFormData.pickupStreet, 
          "state": pickupFormData.pickupState
        },
        "deliveryAddress": {
          "city": deliveryFormData.deliveryCity,
          "pinCode": deliveryFormData.deliveryPincode,
          "flatNo": deliveryFormData.deliveryFlat,
          "buildingName": deliveryFormData.deliveryAddress,
          "streetName": deliveryFormData.deliveryStreet, 
          "state": deliveryFormData.deliveryState
        }
      })
        .then((response) => {
          console.log(response.data.id)
          setOrderId(response.data.id);
          localStorage.setItem('orderInfo', JSON.stringify({ ...response.data, orderId: response.data.id }));
          history.push(`/payment?totalPrice=${cost}`);
        })
        .catch((error) => {
          console.error(error);
        });


    };

    return (
      <div className="container mt-5">
        <h2>Add Order</h2>
        <form onSubmit={handleSubmit}>
          {/* Form fields */}
          <div className="mb-3">
            <label htmlFor="weight" className="form-label">Weight</label>
            <input
              type="text"
              className="form-control"
              id="weight"
              name="weight"
              value={weight}
              onChange={handleWeightChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="vehicleType" className="form-label">Vehicle Type</label>
            <input
              type="text"
              className="form-control"
              id="vehicleType"
              name="vehicleType"
              value={vehicleType}
              readOnly
            />
          </div>

          <h3>Pickup Address</h3>
          <div className="mb-3">
            <label htmlFor="pickupState" className="form-label">State</label>
            <select
              className="form-select"
              id="pickupState"
              name="pickupState"
              value={pickupFormData.pickupState}
              onChange={handlePickupStateChange}
              required
            >
              <option value="">Select State</option>
              {indianStates.map((state, index) => (
                <option key={index} value={state}>{state}</option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label htmlFor="pickupFlat" className="form-label">Flat No</label>
            <input
              type="text"
              className="form-control"
              id="pickupFlat"
              name="pickupFlat"
              value={pickupFormData.pickupFlat}
              onChange={handlePickupInputChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="pickupAddress" className="form-label">Building Name</label>
            <input
              type="text"
              className="form-control"
              id="pickupAddress"
              name="pickupAddress"
              value={pickupFormData.pickupAddress}
              onChange={handlePickupInputChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="pickupStreet" className="form-label">Street Name</label>
            <input
              type="text"
              className="form-control"
              id="pickupStreet"
              name="pickupStreet"
              value={pickupFormData.pickupStreet}
              onChange={handlePickupInputChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="pickupCity" className="form-label">City</label>
            <select
              className="form-select"
              id="pickupCity"
              name="pickupCity"
              value={pickupFormData.pickupCity}
              onChange={handlePickupInputChange}
              required
            >
              <option value="">Select City</option>
              {majorCitiesByState[pickupFormData.pickupState]?.map((city, index) => (
                <option key={index} value={city}>{city}</option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label htmlFor="pickupPincode" className="form-label">Pincode</label>
            <input
              type="text"
              className="form-control"
              id="pickupPincode"
              name="pickupPincode"
              value={pickupFormData.pickupPincode}
              onChange={handlePickupInputChange}
              required
            />
          </div>

          <h3>Delivery Address</h3>
          <div className="mb-3">
            <label htmlFor="deliveryState" className="form-label">State</label>
            <select
              className="form-select"
              id="deliveryState"
              name="deliveryState"
              value={deliveryFormData.deliveryState}
              onChange={handleDeliveryStateChange}
              required
            >
              <option value="">Select State</option>
              {indianStates.map((state, index) => (
                <option key={index} value={state}>{state}</option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label htmlFor="deliveryFlat" className="form-label">Flat No</label>
            <input
              type="text"
              className="form-control"
              id="deliveryFlat"
              name="deliveryFlat"
              value={deliveryFormData.deliveryFlat}
              onChange={handleDeliveryInputChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="deliveryAddress" className="form-label">Building Name</label>
            <input
              type="text"
              className="form-control"
              id="deliveryAddress"
              name="deliveryAddress"
              value={deliveryFormData.deliveryAddress}
              onChange={handleDeliveryInputChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="deliveryStreetName" className="form-label">Street Name</label>
            <input
              type="text"
              className="form-control"
              id="deliveryStreet"
              name="deliveryStreet"
              value={deliveryFormData.deliveryStreet}
              onChange={handleDeliveryInputChange}
              required
            />
          </div>
          <div className="mb-3">
            <label htmlFor="deliveryCity" className="form-label">City</label>
            <select
              className="form-select"
              id="deliveryCity"
              name="deliveryCity"
              value={deliveryFormData.deliveryCity}
              onChange={handleDeliveryInputChange}
              required
            >
              <option value="">Select City</option>
              {majorCitiesByState[deliveryFormData.deliveryState]?.map((city, index) => (
                <option key={index} value={city}>{city}</option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label htmlFor="deliveryPincode" className="form-label">Pincode</label>
            <input
              type="text"
              className="form-control"
              id="deliveryPincode"
              name="deliveryPincode"
              value={deliveryFormData.deliveryPincode}
              onChange={handleDeliveryInputChange}
              required
            />
          </div>

          <a href="/payment" type="submit" className="btn btn-primary" onClick={handleSubmitOrder}>Submit Order</a>
        </form>
      </div>
    );
  };

  export default OrderForm;
