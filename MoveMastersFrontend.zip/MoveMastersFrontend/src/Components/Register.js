import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import {
    MDBContainer,
    MDBRow,
    MDBCol,
    MDBInput,
    MDBBtn,
} from 'mdb-react-ui-kit';
import httpClient from '../http-common';

import { loginCustomer, registerCustomer } from '../Services/OrderService';
import axios from 'axios';
import { Redirect } from 'react-router-dom/cjs/react-router-dom.min';

export default function Register() {
    const history = useHistory();

    const [navigator, SetNavigator] = useState(1)
    const [loginFormData, setLoginFormData] = useState({
        loginEmail: '',
        loginPassword: ''
    });

    const [registerFormData, setRegisterFormData] = useState({
        registerEmail: '',
        registerFirstName: '',
        registerLastName: '',
        registerPassword: '',
        // registerConfirmPassword: '',
        registerMobile: ''
    });

    const [showRegister, setShowRegister] = useState(false);

    const handleLoginChange = (e) => {
        const { name, value } = e.target;
        setLoginFormData({ ...loginFormData, [name]: value });
    };

    const handleRegisterChange = (e) => {
        const { name, value } = e.target;
        setRegisterFormData({ ...registerFormData, [name]: value });

    };

    const toggleRegister = () => {
        setShowRegister(!showRegister);
    };



    const handleLoginSubmit = (e) => {
        e.preventDefault();
        console.log("Login form submitted with data:", loginFormData);
        httpClient.post("customer/api/login", { "email": loginFormData.loginEmail, "password": loginFormData.loginPassword })
            .then((response) => {
                const userData = response.data;
                localStorage.setItem('customer', JSON.stringify(userData));
                // Convert userData.id to integer before comparison
                const userId = parseInt(userData.id);
                if (userId === 1) {
                    history.push('/adminpage');
                } else {
                    history.push('/customerpage');
                }
            })
            .catch((error) => {
                console.error(error);
            })
    };
    



    const handleRegisterSubmit = (e) => {
        const selectedRole = document.getElementById("roleSelect").value;
        if (selectedRole === "customer") {
            registerCustomer(
                {
                    "id": 10,
                    "email": registerFormData.registerEmail,
                    "firstName": registerFormData.registerFirstName,
                    "lastName": registerFormData.registerLastName,
                    "password": registerFormData.registerPassword,
                    "phoneNumber": registerFormData.registerMobile
                }
            ).
                then((response) => {
                    if (response.data !== null) {
                        history.push('/login');
                    }
                    else {
                        console.log("Registration failed...");
                    }
                })
                .catch(error => { console.log("Registration error: " + error) })
            }
        };



        return (
            <MDBContainer className="py-5">
                <MDBRow className="justify-content-center">
                    <MDBCol md="6">
                        {!showRegister ? (
                            <>
                                <h2 className="text-center mb-4">Login</h2>
                                <form onSubmit={handleLoginSubmit}>
                                    <div className="mb-3">
                                        <label htmlFor="loginEmail" className="form-label">Email address</label>
                                        <input
                                            type="email"
                                            className="form-control"
                                            id="loginEmail"
                                            name="loginEmail"
                                            value={loginFormData.loginEmail}
                                            onChange={handleLoginChange}
                                            required
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="loginPassword" className="form-label">Password</label>
                                        <input
                                            type="password"
                                            className="form-control"
                                            id="loginPassword"
                                            name="loginPassword"
                                            value={loginFormData.loginPassword}
                                            onChange={handleLoginChange}
                                            required
                                        />
                                    </div>
                                    <a type="submit" className='btn btn-outline-dark' onClick={handleLoginSubmit}>Login as customer</a>
                                    
                                </form>
                                <p className="text-center mt-3">Don't have an account? <button onClick={toggleRegister} className="btn btn-secondary">Register</button></p>
                            </>
                        ) : (
                            <>

                                {/* Registration form */}
                                <h2 className="text-center mb-4">Register</h2>
                                <form onSubmit={handleRegisterSubmit}>
                                    <div className="d-flex justify-content-between mb-1">
                                        <select id="roleSelect" className="form-select" onChange={(e) => console.log("Selected option:", e.target.value)}>
                                            <option value="">Select Role</option>
                                            <option value="customer">Customer</option>
                                            <option value="deliveryPartner">Delivery Partner</option>
                                        </select>
                                    </div>

                                    <div className="mb-3">
                                        <label htmlFor="registerFirstName" className="form-label">First Name</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="registerFirstName"
                                            name="registerFirstName"
                                            value={registerFormData.registerFirstName}
                                            onChange={handleRegisterChange}
                                            required
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="registerLastName" className="form-label">Last Name</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="registerLastName"
                                            name="registerLastName"
                                            value={registerFormData.registerLastName}
                                            onChange={handleRegisterChange}
                                            required
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="registerEmail" className="form-label">Email address</label>
                                        <input
                                            type="email"
                                            className="form-control"
                                            id="registerEmail"
                                            name="registerEmail"
                                            value={registerFormData.registerEmail}
                                            onChange={handleRegisterChange}
                                            required
                                        />
                                    </div>
                                    <div className="mb-3">
                                        <label htmlFor="registerPassword" className="form-label">Password</label>
                                        <input
                                            type="password"
                                            className="form-control"
                                            id="registerPassword"
                                            name="registerPassword"
                                            value={registerFormData.registerPassword}
                                            onChange={handleRegisterChange}
                                            required
                                        />
                                    </div>
                                   
                                    <div className="mb-3">
                                        <label htmlFor="registerMobile" className="form-label">Mobile Number</label>
                                        <input
                                            type="text"
                                            className="form-control"
                                            id="registerMobile"
                                            name="registerMobile"
                                            value={registerFormData.registerMobile}
                                            onChange={handleRegisterChange}
                                            required
                                        />
                                    </div>
                                    <a type="submit" onClick={() => handleRegisterSubmit(registerFormData)} className='btn btn-outline-dark' ><b>Register</b></a>
                                </form>
                                <p className="text-center mt-3">Already have an account? <button onClick={toggleRegister} className="btn btn-outline-dark">Login</button></p>
                            </>
                        )}
                    </MDBCol>
                </MDBRow>
            </MDBContainer>
        );
    }
