import React from 'react';
import { Card, Row, Col } from 'react-bootstrap';
import { BsClipboardData, BsCreditCard, BsPerson, BsPlusCircle } from 'react-icons/bs';
import '../CustomerPage.css'; 
import { useHistory } from 'react-router-dom'; 

export default function CustomerPage() {
    const history = useHistory();

    const redirectToNewOrder = () => {
        history.push('/neworder');
    };

    const redirectToProfile = () => {
        history.push('/profile');
    };
    return (
        <div className="d-flex justify-content-center align-items-center" style={{ minHeight: '100vh' }}>
            <Row className="justify-content-center">
               
                <Col md={6} lg={3} className="mb-4">
                    <a href="/order"> 
                        <Card className="text-center p-4 cursor-pointer hover-zoom custom-card">
                            <Card.Body>
                                <BsClipboardData size={50} className="mb-3" />
                                <Card.Title>Orders</Card.Title>
                            </Card.Body>
                        </Card>
                    </a>
                </Col>
                
                <Col md={6} lg={3} className="mb-4">
                    <a href="/paymentlist">
                    <Card className="text-center p-4 cursor-pointer hover-zoom custom-card">
                        <Card.Body>
                            <BsCreditCard size={50} className="mb-3" />
                            <Card.Title><span>Payments</span></Card.Title>
                        </Card.Body>
                    </Card>
                    </a>
                </Col>

                <Col md={6} lg={3} className="mb-4">
                    <a href="/profile">
                    <Card className="text-center p-4 cursor-pointer hover-zoom custom-card">
                        <Card.Body>
                            <BsPerson size={50} className="mb-3" />
                            <Card.Title>Profile</Card.Title>
                        </Card.Body>
                    </Card>
                    </a>
                </Col>

                <Col md={6} lg={3} className="mb-4">
                    <a href="/neworder">
                        <Card className="text-center p-4 cursor-pointer hover-zoom custom-card">
                            <Card.Body>
                                <BsPlusCircle size={50} className="mb-3" />
                                <Card.Title onClick={redirectToNewOrder}>New Order</Card.Title>
                            </Card.Body>
                        </Card>
                    </a>
                </Col>
            </Row>
        </div>
    );
}
