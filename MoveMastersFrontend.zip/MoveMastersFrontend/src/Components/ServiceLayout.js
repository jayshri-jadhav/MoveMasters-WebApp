import React from 'react';
import { Container, Row, Col, Card } from 'react-bootstrap';

function ServicesLayout() {
    const linkStyle = {
        textDecoration: 'none' 
    };

    return (
        <div className="d-flex justify-content-center align-items-center outer-container" style={{ minHeight: '100vh' }}>
            <Container>
                <Row className="justify-content-center">
                    <Col xs={12} sm={6} md={4} lg={4} className="service-col mb-4">
                        <a href="/customerpage" style={linkStyle}>
                            <Card className="service-card">
                                <Card.Img variant="top" src="bike.jpg" className="service-img" />
                                <Card.Body>
                                    <Card.Title>Two Wheeler</Card.Title>
                                </Card.Body>
                            </Card>
                        </a>
                    </Col>
                    <Col xs={12} sm={6} md={4} lg={4} className="service-col mb-4">
                        <a href="/customerpage" style={linkStyle}>
                            <Card className="service-card">
                                <Card.Img variant="top" src="https://img.freepik.com/free-vector/hand-drawn-transport-truck_23-2149166402.jpg?w=1060&t=st=1707305013~exp=1707305613~hmac=24e09143ff3c5386e1e874139b1f84bfadd1d46c64c536997f71720a47c02369" className="service-img" />
                                <Card.Body>
                                    <Card.Title>Trucks</Card.Title>
                                </Card.Body>
                            </Card>
                        </a>
                    </Col>
                    <Col xs={12} sm={6} md={4} lg={4} className="service-col mb-4">
                        <a href="/customerpage" style={linkStyle}>
                            <Card className="service-card">
                                <Card.Img variant="top" src="https://img.freepik.com/free-vector/flat-design-house-moving-concept-with-truck_23-2148665508.jpg?w=1060&t=st=1707304915~exp=1707305515~hmac=527099fb017a343089499310cb50ed5043543f4a0a0d95306b6062339d03b7be" className="service-img" />
                                <Card.Body>
                                    <Card.Title>Packers</Card.Title>
                                </Card.Body>
                            </Card>
                        </a>
                    </Col>
                </Row>
            </Container>
        </div>
    );
}

export default ServicesLayout;
