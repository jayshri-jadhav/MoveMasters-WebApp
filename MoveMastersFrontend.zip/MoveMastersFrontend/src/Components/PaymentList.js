
import React, { useEffect, useState } from 'react';
import PaymentService from '../Services/PaymentService'; 
import 'bootstrap/dist/css/bootstrap.min.css';

const PaymentList = () => {
  const [payments, setPayments] = useState([]);

  useEffect(() => {
    const fetchPayments = async () => {
      try {
        const paymentsData = await PaymentService.getAllPayments();
        setPayments(paymentsData);
      } catch (error) {
        console.error('Error fetching payment details:', error.message);
      }
    };

    fetchPayments();
  }, []);

  return (
    <div className="container mt-5">
      <h2>Payment Details</h2>
      <table className="table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Transaction ID</th>
            <th>Amount</th>
            <th>Payment Type</th>
          </tr>
        </thead>
        <tbody>
          {payments.map(payment => (
            <tr key={payment.id}>
              <td>{payment.id}</td>
              <td>{payment.transactionId}</td>
              <td>{payment.amount}</td>
              <td>{payment.paymentType}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default PaymentList;
