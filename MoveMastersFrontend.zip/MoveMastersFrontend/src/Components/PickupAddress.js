import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

export const PickupAddressForm = ({ formData, handleInputChange, handleStateChange, majorCitiesByState, indianStates }) => {
 
   
    const [pickupFormData, setPickupFormData] = useState({
      pickupPincode: '',
      pickupAddress: '',
      pickupCity: '',
      pickupState: '',
    });
   
  
    const handleInputChange = (e, formDataSetter) => {
      const { name, value } = e.target;
      formDataSetter((prevData) => ({ ...prevData, [name]: newValue }));
    };
  
    const handleStateChange = (e, formDataSetter) => {
      const { value } = e.target;
      formDataSetter((prevData) => ({ ...prevData, registerState: value, registerCity: '' }));
    };
  
    const handleSubmit = (e) => {
      e.preventDefault();
      console.log('Order submitted:', {
        weight,
        vehicleType,
        pickupFormData,
        deliveryFormData,
      });
      setWeight('');
      setVehicleType('Car');
      setPickupFormData({ pickupPincode: '', pickupAddress: '', pickupCity: '', pickupState: '' });
      setDeliveryFormData({ deliveryPincode: '', deliveryAddress: '', deliveryCity: '', deliveryState: '' });
    };
 
    return (
    <div>
      <h2>Pickup Address</h2>
      <div className="mb-3">
        <label htmlFor="pickupState" className="form-label">State</label>
        <select
          className="form-select"
          id="pickupState"
          name="pickupState"
          value={formData.pickupState}
          onChange={handleStateChange}
          required
        >
          <option value="">Select State</option>
          {indianStates.map((state, index) => (
            <option key={index} value={state}>{state}</option>
          ))}
        </select>
      </div>
      <div className="mb-3">
        <label htmlFor="pickupFlat" className="form-label">Flat No</label>
        <input
          type="text"
          className="form-control"
          id="pickupFlat"
          name="pickupFlat"
          value={formData.pickupFlat}
          onChange={handleInputChange}
          required
        />
      </div>
      <div className="mb-3">
        <label htmlFor="pickupAddress" className="form-label">Building name</label>
        <input
          type="text"
          className="form-control"
          id="pickupAddress"
          name="pickupAddress"
          value={formData.pickupAddress}
          onChange={handleInputChange}
          required
        />
      </div>
      <div className="mb-3">
        <label htmlFor="pickupCity" className="form-label">City</label>
        <select
          className="form-select"
          id="pickupCity"
          name="pickupCity"
          value={formData.pickupCity}
          onChange={handleInputChange}
          required
        >
          <option value="">Select City</option>
          {majorCitiesByState[formData.pickupState]?.map((city, index) => (
            <option key={index} value={city}>{city}</option>
          ))}
        </select>
      </div>
      <div className="mb-3">
        <label htmlFor="pickupPincode" className="form-label">Pincode</label>
        <input
          type="text"
          className="form-control"
          id="pickupPincode"
          name="pickupPincode"
          value={formData.pickupPincode}
          onChange={handleInputChange}
          required
        />
      </div>
    </div>
  );
};
