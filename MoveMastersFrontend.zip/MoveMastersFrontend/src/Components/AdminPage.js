import React, { useState, useEffect } from 'react';
import httpClient from '../http-common';

const AdminPage = () => {
  const [requests, setRequests] = useState([]);

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = () => {
    httpClient.get('/notvisited')
      .then((response) => {
        console.log(response.data)
        setRequests(response.data);
      })
      .catch((error) => {
        console.error('Error fetching requests:', error);
      });
  };
  const handleAccept = (requestId) => {
    var status = 'SHIPPED'; 
  console.log(status);
    const requestToUpdate = requests.find(request => request.id === requestId);
  
    if (requestToUpdate) {
      const orderId = requestToUpdate.orderId;
        
      httpClient.put(`/order/${orderId}`, status)
        .then((response) => {
          console.log('Order status updated successfully:', response.data);
          fetchRequests();
        })
        .catch((error) => {
          console.error('Error updating order status:', error);
        });
    } else {
      console.error('Request with requestId', requestId, 'not found in the requests.');
    }
  };
  
  

  

  const handleDecline = (requestId) => {
    console.log('Request declined:', requestId);
  };

  return (
    <div className="container mt-5">
      <h2>Admin Page</h2>
      <div className="row">
        {requests.length === 0 ? (
          <div className="col-md-12">
            <p>No requests</p>
          </div>
        ) : (
          requests.map((request) => (
            <div className="col-md-4 mb-3" key={request.id}>
              <div className="card">
                <div className="card-body">
                  <h5 className="card-title">Customer Id: {request.customerId}</h5>
                  <p className="card-text">Pickup Address: {request.pickupAddress}</p>
                  <p className="card-text">Delivery Address: {request.deliveryAddress}</p>
                  <p className="card-text">Total Cost: {request.cost}</p>
                  <button className="btn btn-success" onClick={() => handleAccept(request.id)}>Accept</button>
                  &nbsp;
                  <button className="btn btn-danger ml-2" onClick={() => handleDecline(request.id)}>Decline</button>
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default AdminPage;
