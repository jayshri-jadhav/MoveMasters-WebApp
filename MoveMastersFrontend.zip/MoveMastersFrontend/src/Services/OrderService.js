import httpClient from '../http-common';

export const getOrder=(id)=>{
    return httpClient.get(`/order/${id}`);
}
export const loginCustomer = (email, password) => { 
    return httpClient.post(`/customer/login`,{email,password});
};


export const registerCustomer = (e) =>
{
    return httpClient.post(`/customer/register`,e);
} 

 