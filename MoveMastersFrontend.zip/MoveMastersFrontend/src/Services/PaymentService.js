
import httpClient from '../http-common'; 
import Payment from '../Components/PaymentClass'; 

const PaymentService = {
  getAllPayments: async () => {
    try {
      const response = await httpClient.get('/payments');
      
      if (!response.data) {
        throw new Error('Failed to fetch payment details');
      }

      const paymentData = response.data;
      return paymentData.map(payment => new Payment(
        payment.id,
        payment.transactionId,
        payment.amount,
        payment.paymentType
      ));
    } catch (error) {
      console.error('Error fetching payment details:', error.message);
      throw error;
    }
  },
};

export default PaymentService;
