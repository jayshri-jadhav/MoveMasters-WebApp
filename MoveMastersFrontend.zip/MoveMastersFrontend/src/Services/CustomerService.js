import httpClient from '../http-common'; 
import Customer from '../Components/CustomerClass';
const CustomerService = {
  getLoggedInCustomer: async () => {
    try {
      const response = await httpClient.get('/loggedInCustomer');
      
      if (!response.data) {
        throw new Error('Failed to fetch customer details');
      }

      const customerData = response.data;
      return new Customer(
        customerData.id,
        customerData.firstname,
        customerData.lastname,
        customerData.email,
        customerData.password,
        customerData.phoneno
      );
    } catch (error) {
      console.error('Error fetching customer details:', error.message);
      throw error;
    }
  },
};

export default CustomerService;
