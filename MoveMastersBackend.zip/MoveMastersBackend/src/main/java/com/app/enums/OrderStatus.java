package com.app.enums;

public enum OrderStatus {
	PENDING,SHIPPED,DELIVERED

}
