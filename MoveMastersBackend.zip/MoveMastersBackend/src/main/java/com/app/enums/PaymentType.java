package com.app.enums;

public enum PaymentType 
{
	UPI,CREDIT,CASH
}
