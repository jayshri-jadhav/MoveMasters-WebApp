package com.app.enums;

public enum PaymentStatus 
{
	PENDING,COMPLETE,REFUND,FAILED
}
